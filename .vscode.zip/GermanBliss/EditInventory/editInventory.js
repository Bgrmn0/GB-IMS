document.addEventListener('DOMContentLoaded', async function () {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    if (!id) {
        alert("No inventory ID provided.");
        return;
    }

    // Load current item data to pre-fill the form
    try {
        const res = await fetch(`/inventory/${id}`);
        const item = await res.json();
        if (!res.ok) throw new Error(item.error);

        document.getElementById('make').value = item.make;
        document.getElementById('model').value = item.model;
        document.getElementById('description').value = item.description;
        document.getElementById('cost').value = item.cost;
        document.getElementById('status').value = item.status;

    } catch (err) {
        console.error("Failed to load item:", err);
        alert("Error loading item.");
    }

    // Submit update
    document.getElementById('editInventoryForm').addEventListener('submit', async function (event) {
        event.preventDefault();

        const data = {
            make: document.getElementById('make').value,
            model: document.getElementById('model').value,
            description: document.getElementById('description').value,
            cost: parseFloat(document.getElementById('cost').value),
            quantity: 1,
            status: document.getElementById('status').value
        };

        try {
            const response = await fetch(`/update-inventory/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            if (response.ok) {
                alert('Item updated successfully.');
            } else {
                alert(`Update failed: ${result.error}`);
            }
        } catch (err) {
            console.error(err);
            alert('Failed to update item.');
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');

    if (!id) {
        alert('No inventory ID provided.');
        return;
    }

    fetch(`/inventory/${id}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load item.');
            return response.json();
        })
        .then(item => {
            document.getElementById('make').value = item.make;
            document.getElementById('model').value = item.model;
            document.getElementById('description').value = item.description;
            document.getElementById('cost').value = item.cost;
            document.getElementById('status').value = item.status;

            // Attach submit handler
            document.getElementById('editInventoryForm').addEventListener('submit', function (e) {
                e.preventDefault();

                const updatedItem = {
                    make: document.getElementById('make').value,
                    model: document.getElementById('model').value,
                    description: document.getElementById('description').value,
                    cost: document.getElementById('cost').value,
                    status: document.getElementById('status').value
                };

                fetch(`/inventory/${id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(updatedItem)
                })
                    .then(response => {
                        if (!response.ok) throw new Error('Failed to update item.');
                        alert('Item updated successfully.');
                        window.location.href = '../ViewInventory/View-inventory.html';
                    })
                    .catch(error => {
                        console.error(error);
                        alert('Failed to update item.');
                    });
            });
        })
        .catch(error => {
            console.error(error);
            alert('Error loading item.');
        });
});
